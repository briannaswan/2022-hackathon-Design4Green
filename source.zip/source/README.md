# Design4Green Hackathon 2022
As part of the Design4Green challenge; this repository includes a Sustainable digital trainings website with a mapping visualization, search engine and cart functionality.

## Running in local
Step 1: git clone https://github.com/briannaswan/2022-hackathon-Design4Green.git

Step 2: Navigate to the directory. Run an http server:
```
npx http-server -o
```

## Running with Apache web server
Step 1: Open browser and type the following ip address/vps domain:
```
54.36.99.70
http://vps-aa433cf0.vps.ovh.net/
```
## Disclaimer
The sources of this challenge remains the property of the team of developers:
```
Team Nine, Number 49
Brianna Swan
Karthikeyan Suresh
Monica Vasquez
Asif Mahmod
```